﻿using System;
using System.Data;
using System.Windows.Forms;

namespace homework
{
    public partial class Form1 : Form
    {
        private books bk;
        public Form1()
        { 
            InitializeComponent();
            bk = new books();
            radioButton1.Text = "Номер УДК";
            radioButton2.Text = "Имя Автора";
            radioButton3.Text = "Название";
            radioButton4.Text = "Год издания";
            
            sorting_init();
        }

        private void initBTree()
        {
            bk.BTreeFromDatatable();
            treeView1.Nodes.Clear();
            
            //имя файла, таблицы, полки....
            TreeNode root = treeView1.Nodes.Add(bk.seacrch_string);
            
            bk.TreeFromBTree(root, bk.bt);
            treeView1.ExpandAll();
        }

        private void sorting_init()
        {
            if (radioButton1.Checked)
            {
                bk.SortingColumnIndex = 0;
            }
            else if (radioButton2.Checked)
            {
                bk.SortingColumnIndex = 1;
            }
            else if (radioButton3.Checked)
            {
                bk.SortingColumnIndex = 2;
            }
            else if (radioButton4.Checked)
            {
                bk.SortingColumnIndex = 3;
            }
            initBTree();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            string add_book = textBox1.Text;
                if (add_book != "")
                {
                    bk.add(add_book);
                    initBTree();
                }
                else
                {
                    MessageBox.Show("Введите полную информацию о книге");
                }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var tmp = bk.bt.search(textBox1.Text);
            if (tmp != null)
            { 
                dataGrid1.DataSource = tmp.data.CopyToDataTable();
            }
            else
            {
                MessageBox.Show("Введите корректные данные для поиска");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var tmp = textBox1.Text;
            if (tmp != "" & tmp.Length == 5)
            { 
                bk.remove_book(tmp);
                initBTree();
            }
            else
            {
                MessageBox.Show("Введите корректные данные для удаления");
            }
        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                sorting_init();
            }
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                sorting_init();
            }        
        }
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                sorting_init();
            }
        }
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            {
                sorting_init();
            }
        }

        private void treeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            var tmp = bk.bt.search(e.Node.Text);
            if (tmp != null)
            {
                dataGrid1.DataSource = tmp.data.CopyToDataTable();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            bk.read_from_csv();
            bk.BTreeFromDatatable();
            treeView1.Nodes.Clear();
            
            //имя файла, таблицы, полки....
            TreeNode root = treeView1.Nodes.Add(bk.seacrch_string);
            
            bk.TreeFromBTree(root, bk.bt);
            treeView1.ExpandAll();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            bk.write_to_csv();
        }
    }
}