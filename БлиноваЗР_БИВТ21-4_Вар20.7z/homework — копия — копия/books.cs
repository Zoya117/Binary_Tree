﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace homework
{
   class books : DataTable
    {
        public DataTable dt;
        public DataTable dt1;
        public BinaryTree<string> bt;
        public int SortingColumnIndex;
        public string seacrch_string;
        public books()
        {
            dt = new DataTable("Books");
            SortingColumnIndex = 2;
            seacrch_string = "Books";
            
            DataColumn[] cols =
            {
                new DataColumn("Number_UDK",typeof(String)),
                new DataColumn("Auth_Name",typeof(String)),
                new DataColumn("Name",typeof(String)), 
                new DataColumn("Year_of_publishing",typeof(string)),
                new DataColumn("Amount",typeof(Int32)),
            };
            dt.Columns.AddRange(cols);
            
            DataColumn[] columns = new DataColumn[4];
            columns[0] = dt.Columns["Number_UDK"];
            columns[1] = dt.Columns["Auth_Name"];
            columns[2] = dt.Columns["Name"];
            columns[3] = dt.Columns["Year_of_publishing"];
            dt.PrimaryKey = columns;
            
            dt1 = dt.Clone();
            
            init_dt();
        }

        public void TreeFromBTree(TreeNode tnode, BinaryTree<string> bttnode)
        {
            var node = tnode.Nodes.Add(bttnode.val);
            if (bttnode.left == null)
            {
                return;
            }
            TreeFromBTree(node, bttnode.left);
            if (bttnode.right == null)
            {
                return;
            }
            TreeFromBTree(node, bttnode.right);
        }
        
        public void BTreeFromDatatable()
        {
            string SortingColumnName = dt.Columns[SortingColumnIndex].ColumnName;
            var data = dt.AsEnumerable()
                .Select(s => s)
                .OrderBy(tmp => tmp.Field<string>(SortingColumnName))
                .GroupBy(g => g.Field<string>(SortingColumnName));

            bt = BTreefromSortDatatable_Load(data, 0, data.Count());
        }
        private BinaryTree<string> BTreefromSortDatatable_Load(IEnumerable<IGrouping<string, DataRow>> tree, int pos, int size)
        {
            if (size <= 0) return null;
            else
            {
                int  numb_right = size / 2;
                int numb_left = size / 2; 
                int middle = size / 2;
                var node = new BinaryTree<string>(tree.ElementAt(middle + pos).Key.ToString(), null);
                node.data = tree.ElementAt(pos + middle).ToArray();
                numb_right = size - middle - 1;
                numb_left = middle;
                
                
                node.left = BTreefromSortDatatable_Load(tree, pos, numb_left);
                node.right = BTreefromSortDatatable_Load(tree, pos + middle + 1, numb_right);

                return node;
            }
        }
        
        public void remove_book(string removed_book)
        {
            string SortingColumnName = dt.Columns[SortingColumnIndex].ColumnName;
            var sel = dt.AsEnumerable()
                                                    .Where(w => w.Field<string>(SortingColumnName)
                                                    .Equals(removed_book));
            if (sel != null)
            {
                foreach (var row in sel.ToList())
                    row.Delete();
                dt.AcceptChanges();
            }
        }

        public void init_dt()
        {
            Object[][] rows = 
            {
                new Object[]{1, "Пушкин А.С", "Капитанская дочка", "1836 год", 1},
                new Object[]{2, "Достоевский Ф.М", "Преступление и наказание", "1866 год", 1},
                new Object[]{3, "Гоголь Н.В", "Мёртвые души", "1842 год", 1},
                new Object[]{4, "Шекспир У.", "Гамлет", "1603 год", 1},
                new Object[]{5, "Чехов А.П", "Хамелеон", "1884 год", 1},
                new Object[]{6, "Булгаков М.А", "Мастер и маргарита", "1967 год", 1},
                new Object[]{17, "Достоевский Ф.М", "Бесы", "1872 год", 1},
            };

            foreach (var s in rows) 
            {
                dt.Rows.Add(s);
            }
        }

        public void add(string book)
        {
            Object[] tmp = new Object[] {};
            tmp = tmp.Concat(book.Split(';')).ToArray(); //прибавляем к массиву из элемента null нашу строку, преобразованную в массив
            if (tmp.Length == 5)
            {
                dt.Rows.Add(tmp);
            }
            else
            {
                MessageBox.Show("Неверный формат входной строки");
            }
            dt.AcceptChanges();
                
            
        }
        
        public void write_to_csv()
        {
            StringBuilder sb = new StringBuilder();
            foreach (DataColumn cln in dt.Columns)
            {
                sb.AppendLine(string.Join(";", cln.ColumnName,cln.DataType));
            }
            File.WriteAllText("_model.csv", sb.ToString());
            sb.Clear();
            foreach (DataRow row in dt.Rows)
            {
                string[] fields = row.ItemArray.Select(field => field.ToString()).
                    ToArray();
                sb.AppendLine(string.Join(";", fields));
            }
            File.WriteAllText("_data.csv", sb.ToString());
        }
        
        public void read_from_csv()
        {
            string[] rows;
            dt.Rows.Clear();
            dt.PrimaryKey = null;
            dt.Columns.Clear();
            using (StreamReader sr = new StreamReader("_model.csv"))
            {
                string row;
                while ((row = sr.ReadLine()) != null)
                {
                    rows = row.Split(';');
                    dt.Columns.Add(new DataColumn(rows[0], Type.GetType(rows[1])));
                }
            }

            using (StreamReader sr = new StreamReader("_data.csv"))
            {
                string row;
                while((row = sr.ReadLine()) != null)
                {
                    DataRow dr = dt.NewRow();
                    dr.ItemArray = row.Split(';');
                    dt.Rows.Add(dr);
                }
            }
            
        }
    }
}